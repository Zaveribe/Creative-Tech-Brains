class Card {
    private String color;
    private String value;

    public Card(String color, String value) {
        this.color = color;
        this.value = value;
    }

    public String getColor() {
        return color;
    }

    public String getValue() {
        return value;
    }

    public boolean isActionCard() {
        return value.equals("Skip") || value.equals("Reverse") || value.equals("Draw Two");
    }

    public boolean isWildCard() {
        return color.equals("Wild");
    }

    public boolean isNumberCard() {
        return !isActionCard() && !isWildCard();
    }

    public boolean isSameColor(Card otherCard) {
        return color.equals(otherCard.getColor());
    }

    public boolean isSameValue(Card otherCard) {
        return value.equals(otherCard.getValue());
    }

    @Override
    public String toString() {
        return color + " " + value;
    }

    // You can add more methods for card-specific behaviors, if needed
}
