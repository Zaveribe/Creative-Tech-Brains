import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

class Player {
    private String name;
    private List<Card> hand;

    public Player(String name) {
        this.name = name;
        this.hand = new ArrayList<>(); // Initialize the player's hand (list of cards)
    }

    public String getName() {
        return name;
    }

    public void drawCard(Card card) {
        hand.add(card);
    }

    public Card playCard(int index) {
        if (index >= 0 && index < hand.size()) {
            return hand.remove(index); // Remove and return the played card
        }
        return null; // Invalid index, card couldn't be played
    }

    public Card playCard() {
        if (hand.isEmpty()) {
            System.out.println("Your hand is empty. You need to draw a card.");
            return null;
        }

        System.out.println("Your hand: " + hand);
        System.out.println("Enter the index of the card you want to play (0 to " + (hand.size() - 1) + "), or -1 to skip: ");

        Scanner scanner = new Scanner(System.in);
        int index = scanner.nextInt();

        if (index == -1) {
            return null; // Player chooses to skip their turn
        }

        if (index >= 0 && index < hand.size()) {
            return hand.remove(index); // Remove and return the played card
        } else {
            System.out.println("Invalid index. Please choose a valid index.");
            return playCard(); // Retry the card selection
        }
    }


    public boolean hasMatchingCard(Card topCard) {
        for (Card card : hand) {
            if (card.getColor().equals(topCard.getColor()) || card.getValue().equals(topCard.getValue())) {
                return true; // Player has a matching card
            }
        }
        return false; // Player doesn't have a matching card
    }

    public boolean hasUno() {
        return hand.size() == 1; // Player has only one card left
    }

    public boolean hasWon() {
        return hand.isEmpty(); // Player's hand is empty, they have won
    }

    @Override
    public String toString() {
        return name + "'s hand: " + hand;
    }

    // You can add more methods for other player-related behaviors
}
