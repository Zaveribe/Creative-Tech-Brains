import java.util.List;

class UNOGame {
    private List<Player> players;
    private Deck deck;
    private List<Card> discardPile;
    private int currentPlayerIndex;

    public UNOGame(List<Player> players, Deck deck, List<Card> discardPile) {
        this.players = players;
        this.deck = deck;
        this.discardPile = discardPile;
        this.currentPlayerIndex = 0; // Initialize other properties
    }

    public void startGame() {
        boolean gameWon = false;
        while (!gameWon) {
            Player currentPlayer = players.get(currentPlayerIndex);
            Card topCard = discardPile.get(discardPile.size() - 1);

            // Display the top card on the discard pile
            System.out.println("Top card: " + topCard);

            // Check if the player has a matching card, draw if necessary
            if (!currentPlayer.hasMatchingCard(topCard)) {
                Card drawnCard = deck.drawCard();
                if (drawnCard != null) {
                    System.out.println(currentPlayer.getName() + " draws a card.");
                    currentPlayer.drawCard(drawnCard);
                }
            }

            // Player's turn: Allow them to play a card or draw
            Card playedCard = currentPlayer.playCard(); // Implement the logic for player's card selection
            if (playedCard != null) {
                discardPile.add(playedCard);
                System.out.println(currentPlayer.getName() + " plays " + playedCard);
                // Implement card-specific effects if needed (e.g., action cards)
            } else {
                // Draw card from the deck
                Card drawnCard = deck.drawCard();
                if (drawnCard != null) {
                    System.out.println(currentPlayer.getName() + " draws a card.");
                    currentPlayer.drawCard(drawnCard);
                }
            }

            // Check for win conditions
            if (currentPlayer.hasUno()) {
                System.out.println(currentPlayer.getName() + " has UNO!");
            }
            if (currentPlayer.hasWon()) {
                gameWon = true;
                System.out.println(currentPlayer.getName() + " has won!");
            }

            currentPlayerIndex = (currentPlayerIndex + 1) % players.size();
        }
    }
}
